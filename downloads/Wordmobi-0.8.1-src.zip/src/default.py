import e32
import sys
if float(e32.pys60_version[:3]) >= 1.9:
    sys.path.append("c:\\data\\python")

import wordmobi

wordmobi.WordMobi().run()
