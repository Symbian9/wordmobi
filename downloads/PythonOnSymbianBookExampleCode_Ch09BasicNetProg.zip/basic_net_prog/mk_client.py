'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# File like sockets - client
# btsocket can be used as well
import socket
import e32
 
sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
sock.connect(('127.0.0.1',54321))
fsock = sock.makefile()

for i in range(5):
    msg = u"Sending line %d ...\n" % i
    fsock.write(msg)
    print msg
    # call flush to send pending bytes
    fsock.flush()
    # slow down for better comprehension
    e32.ao_sleep(1)
    
sock.close()
