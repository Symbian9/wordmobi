'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# Sending broadcast messages
import btsocket
import e32

BCIP = "255.255.255.255"
PORT = 54321
 
sock = btsocket.socket(btsocket.AF_INET,btsocket.SOCK_DGRAM)
sock.setsockopt(btsocket.SOL_SOCKET,btsocket.SO_BROADCAST, True)
for i in range(10):
    n = sock.sendto('hello world',(BCIP,PORT))
    print "Message sent (%d bytes)" % n
    e32.ao_sleep(2)
