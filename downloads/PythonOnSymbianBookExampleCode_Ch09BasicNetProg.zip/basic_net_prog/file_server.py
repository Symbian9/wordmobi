'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# File upload server
import sys
try:
    # Try to import btsocket as socket
    sys.modules['socket'] = __import__('btsocket')
except ImportError:
    pass
import socket
from appuifw import *
import os
import e32
import struct
 
class FileUpload(object):
    """ File upload server class
    """
    def __init__(self):
        self.lock = e32.Ao_lock()
        self.dir = "e:\\file_upload"
        if not os.path.isdir(self.dir):
            os.makedirs(self.dir)
        self.apo = None
        self.port = 54321
        self.new_line = u"\u2029"
        app.title = u"File upload"
        app.screen = "normal"
        app.menu = [(u"About", self.about)]
        self.body = Text()
        app.body = self.body
        self.lock.wait()
 
    def recv_file(self,cs,addr):
        """ Given a client socket (cs), receive a new file
            and save it at self.dir
        """
        data = ""
        name = ""
        size = 0
        # waiting for file name
        while True:
            n = data.find("\n")
            if n >= 0:
                name = data[:n]
                data = data[n+1:]
                break
            buf = cs.recv(1024)
            data += buf
 
        # waiting for file size (may be useful for limits checking)
        while True:
            n = data.find("\n")
            if n >= 0:
                # unpack one long (L) using big endian (>) endianness
                size = struct.unpack(">L",data[:n])[0]
                data = data[n+1:]
                break
            buf = cs.recv(1024)
            data += buf
 
        self.body.add(u"Uploading %s (%d bytes)" % (name,size) + self.new_line)
        # waiting for file contents
        fname = os.path.join(self.dir,name)
        f = open(fname,"wb")
        while True:
            f.write(data)
            data = cs.recv(1024)
            if not data:
                break
        self.body.add(u"Finished." + self.new_line)
        cs.close()
        f.close()
 
    def server(self,ip,port):
        """ Starts a mono thread server at ip, port
        """
        s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        s.bind((ip,port))
        s.listen(1)
 
        while True:
            (cs,addr) = s.accept()
            self.body.add(u"Connect to %s:%d" % (addr[0],addr[1]) + self.new_line)
            self.recv_file(cs,addr)
 
    def sel_access_point(self):
        """ Select and set the default access point.
            Return the access point object if the selection was done or None if not
        """
        aps = socket.access_points()
        if not aps:
            note(u"No access points available","error")
            return None
 
        ap_labels = map(lambda x: x['name'], aps)
        item = popup_menu(ap_labels,u"Access points:")
        if item is None:
            return None
 
        apo = socket.access_point(aps[item]['iapid'])
        socket.set_default_access_point(apo)
 
        return apo
 
    def about(self):
        note(u"File upload for PyS60","info")
 
    def run(self):
        self.apo = self.sel_access_point()
        if self.apo:
            self.apo.start()
            self.body.add(u"Starting server." + self.new_line)
            self.body.add(u"IP = %s" % self.apo.ip() + self.new_line)
            self.body.add(u"Port = %d" % self.port + self.new_line)
            self.body.add(u"Repository = %s" % (self.dir) + self.new_line)
            self.server(self.apo.ip(),self.port)
            self.lock.wait()
        app.set_tabs( [], None )
        app.menu = []
        app.body = None
        app.set_exit()
 
if __name__ == "__main__":
    app = FileUpload()
    app.run()
