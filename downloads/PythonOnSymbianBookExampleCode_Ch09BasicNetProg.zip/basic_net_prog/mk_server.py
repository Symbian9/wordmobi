'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# File like sockets - server
# btsocket can be used as well
import socket
 
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.bind(('127.0.0.1',54321))
s.listen(1)

while True:
    sock,addr = s.accept()
    fsock = sock.makefile()
    print "New connection from",addr
    while True:
        line = fsock.readline()
        if not line:
            print "Connection closed"
            break
        print "=> ",line
