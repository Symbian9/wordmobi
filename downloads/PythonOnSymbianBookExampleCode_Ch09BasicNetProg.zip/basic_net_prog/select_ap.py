'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# Selecting access point
from appuifw import *
import socket 
 
def sel_access_point():
    """ Select the default access point.
        Return True if the selection was done or False if not
    """
    aps = socket.access_points()
    if not aps:
        note(u"No access points available","error")
        return False
 
    ap_labels = map(lambda x: x['name'], aps)
    item = popup_menu(ap_labels,u"Access points:")
    if item is None:
        return False
 
    socket.set_default_access_point(aps[item]["name"])
 
    return True
   
if sel_access_point():
    note(u"Connect!","info")
