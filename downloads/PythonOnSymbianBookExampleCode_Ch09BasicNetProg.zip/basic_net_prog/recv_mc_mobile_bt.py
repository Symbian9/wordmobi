'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
import time
import sys
import btsocket
from appuifw import popup_menu, note

GROUP = "224.202.20.30"
PORT = 54321

def sel_access_point_bt():
    aps = btsocket.access_points()
    if not aps:
        note(u"No access points available","error")
        return None
    
    ap_labels = map(lambda x: x['name'], aps)
    item = popup_menu(ap_labels,u"Access points:")
    if item is None:
        return None
    
    apo = btsocket.access_point(aps[item]['iapid'])
    btsocket.set_default_access_point(apo)
    return apo

def join_grp(sock,grp,itf):
    # enabling multicasting option for interface itf
    sock.setsockopt(btsocket.SOL_IP,
                    btsocket.IP_MULTICAST_IF,
                    btsocket.inet_aton(itf))
    # joining to multicast group grp in interface itf
    sock.setsockopt(btsocket.SOL_IP,
                    btsocket.IP_ADD_MEMBERSHIP,
                    btsocket.inet_aton(grp)+btsocket.inet_aton(itf))
 
def leave_grp(sock,grp,ITF_ADDR):
    # removing
    sock.setsockopt(btsocket.SOL_IP,
                    btsocket.IP_DROP_MEMBERSHIP,
                    btsocket.inet_aton(grp)+btsocket.inet_aton(ITF_ADDR))

apo = sel_access_point_bt()
if apo:
    apo.start()
    ITF_ADDR = apo.ip()
    sock = btsocket.socket(btsocket.AF_INET,btsocket.SOCK_DGRAM)
    sock.bind((ITF_ADDR,PORT))
    join_grp(sock,GROUP,ITF_ADDR)
 
    for n in range(10):
        (data,addr) = sock.recvfrom(1500)
        print "Received ",data,"from",addr
     
    leave_grp(sock,GROUP,ITF_ADDR)
