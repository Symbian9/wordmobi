'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# PC multicast server
import time
import sys
import socket
 
GROUP = "224.202.20.30"
PORT = 54321
ITF_ADDR = '10.0.0.102'

def join_grp(sock,grp,itf):
    # enabling multicasting option for interface itf
    sock.setsockopt(socket.SOL_IP,
                    socket.IP_MULTICAST_IF,
                    socket.inet_aton(itf))
    # joining to multicast group grp in interface itf
    sock.setsockopt(socket.SOL_IP,
                    socket.IP_ADD_MEMBERSHIP,
                    socket.inet_aton(grp)+socket.inet_aton(itf))
 
def leave_grp(sock,grp,ITF_ADDR):
    # removing
    sock.setsockopt(socket.SOL_IP,
                    socket.IP_DROP_MEMBERSHIP,
                    socket.inet_aton(grp)+socket.inet_aton(ITF_ADDR))
 
sock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
sock.bind((ITF_ADDR,PORT))
join_grp(sock,GROUP,ITF_ADDR)
 
for n in range(10):
    (data,addr) = sock.recvfrom(1500)
    print "Received ",data,"from",addr
 
leave_grp(sock,GROUP,ITF_ADDR)
