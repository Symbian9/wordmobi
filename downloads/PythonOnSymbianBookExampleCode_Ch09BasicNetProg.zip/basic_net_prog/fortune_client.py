'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# Fortune client
 
from socket import *
from appuifw import note

HOST = "10.0.0.100"
PORT = 54321
 
s = socket(AF_INET,SOCK_STREAM)
s.connect((HOST,PORT))
 
fortune = u""
while True:
    data = s.recv(1024)
    if not data:
        break
    fortune += data
 
s.close()
 
note(fortune,"info")
