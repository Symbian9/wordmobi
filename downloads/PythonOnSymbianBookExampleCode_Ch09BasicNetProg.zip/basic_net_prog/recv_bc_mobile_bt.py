'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# Receiving broadcast messages
import btsocket
from appuifw import popup_menu

PORT = 54321
sock = btsocket.socket(btsocket.AF_INET,btsocket.SOCK_DGRAM)
sock.bind(('0.0.0.0',PORT))

def sel_access_point_bt():
    aps = btsocket.access_points()
    if not aps:
        note(u"No access points available","error")
        return None
    
    ap_labels = map(lambda x: x['name'], aps)
    item = popup_menu(ap_labels,u"Access points:")
    if item is None:
        return None
    
    apo = btsocket.access_point(aps[item]['iapid'])
    btsocket.set_default_access_point(apo)
    return apo
 
apo = sel_access_point_bt()
if apo:
    apo.start()
    for i in range(10):
        (data,addr) = sock.recvfrom(1500)
        print "Received ",data,"from",addr
