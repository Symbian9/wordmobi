'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# Selecting access point
from appuifw import *
import btsocket 

def sel_access_point_bt():
    """ Select the default access point.
        Return the acess point if the selection was done
        or None if not
    """
    aps = btsocket.access_points()
    if not aps:
        note(u"No access points available","error")
        return None
    
    ap_labels = map(lambda x: x['name'], aps)
    item = popup_menu(ap_labels,u"Access points:")
    if item is None:
        return None
    
    apo = btsocket.access_point(aps[item]['iapid'])
    btsocket.set_default_access_point(apo)
    
    return apo

apo = sel_access_point_bt()
if apo:
    apo.start()
    note(u"Connect! IP "+apo.ip(),"info")

    
