# Multithread demo2
from threading import Thread
from time import sleep

class MyThread(Thread):
    def __init__(self,n,m):
        self.n = n
        self.m = m
        Thread.__init__(self)
    def run(self):
        for i in xrange(self.n):
            print "-->",i
            sleep(self.m)

t = MyThread(5,2)
t.start()
t.join()
