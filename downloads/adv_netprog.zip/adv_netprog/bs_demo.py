# BeautifulSoup demo
import sys
sys.path.append("e:\\python\\")
from BeautifulSoup import BeautifulSoup

html = u"""<html><body><h1 style="text-align:center">Heading 1</h1>
<p>Page content goes here.
<h2>And here.</h2></p><a href="http://croozeus.com/blogs" 
alt="Croozeus link">Croozeus</a><br/>
<a href="http://www.python.org">Python</a><br/>
<h1>The end.</h1></body>
</html>"""

soup = BeautifulSoup(html)
print soup.prettify()



links = soup.findAll({'a':True})
for link in links:
    print "-->", link['href'].encode('utf-8')



for link in links:
    link['alt'] = link['href']
print soup.prettify()



p = soup.find('p')
print p.contents
print p.contents[0]
print p.contents[1]
print p.contents[1].contents



p = soup.p
h2 = p.findChild()
print h2



h1=soup.h1
while h1:
    print h1
    h1 = h1.findNextSibling('h1')

