# XML-RPC demo 1
import xmlrpclib
blog = 'http://wordmobi.wordpress.com/xmlrpc.php'
server = xmlrpclib.ServerProxy(blog)
rposts = server.metaWeblog.getRecentPosts(0,"put_user_here","put_pass_here", 5)
for post in rposts:
    print "-> %s" % post['title']

# XML-RPC demo
cats = server.wp.getCategories(0,"put_user_here","put_pass_here")
for c in cats:
    print c['categoryName']
