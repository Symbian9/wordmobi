# Wordpress demo
import socket
from appuifw import *
import xmlrpclib
import e32

WP_USER = "YOUR_USERNAME"
WP_PASS = "YOUR_PASSWORD"
WP_BLOG = "http://YOUR_BLOG_DOMAIN/xmlrpc.php"

class ExpressPost(object):
    def __init__(self):
        self.lock = e32.Ao_lock()
        app.title = u"Express Post"
        app.screen = "normal"
        self.title = u""
        self.contents = u""
        app.menu = [(u"Send post",self.send_post),
                    (u"Exit", self.close_app)]
        self.body = Listbox([(u"",u"")],self.edit)
        app.body = self.body
        self.blog = xmlrpclib.ServerProxy(WP_BLOG)
        self.update()
        self.lock.wait()

    def edit(self):
        idx = self.body.current()
        if idx == 0:
            title = query(u"Title", "text", self.title)
            if title is not None:
                self.title = title
        elif idx == 1:
            contents = query(u"Contents", "text", self.contents)
            if contents is not None:
                self.contents = contents
        self.update()

    def update(self):
        self.body.set_list([(u"Title",self.title),(u"Contents",self.contents)])

    def send_post(self):
        "Adding a new post to the blog"
        post = { 'title' : self.unicode_to_utf8(self.title),
                 'description' : self.unicode_to_utf8(self.contents)}
        try:
            # use 0 if you want a draft post
            self.blog.metaWeblog.newPost(0,WP_USER,WP_PASS,post,1)
        except:
            note(u"Could not send the post!","error")
        else:
            note(u"Post published!","info")
    
    def unicode_to_utf8(self,s):
        "Converting string to the default encoding of wordpress"
        return s.encode('utf-8')

    def close_app(self):
        self.lock.signal()
        
ExpressPost()

    
