# Semaphore demo
from threading import Thread, Semaphore
from time import sleep
from random import randint

class MyThread(Thread):
    resource = []
    def __init__(self,tid,s):
        self.tid = tid
        self.sema = s
        Thread.__init__(self)
    def insert(self,v):
        self.sema.acquire()
        MyThread.resource.append(v)
        self.sema.release()
    def run(self):
        for i in xrange(5):
            self.insert((self.tid,i))
            sleep(randint(1,4))

s = Semaphore(1)
tsks = [ MyThread(n,s) for n in xrange(5) ]
[ t.start() for t  in tsks ]
[ t.join() for t  in tsks ]

print MyThread.resource
