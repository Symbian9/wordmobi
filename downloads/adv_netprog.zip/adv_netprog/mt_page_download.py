# Multithread page downloader
import urllib
from threading import Thread
from Queue import Queue
from appuifw import *
import os
import e32
 
class get_page(Thread):
    def __init__(self,url,qlog):
        self.url = url
        self.fname = os.path.join(u"e:\\python\\",url[url.rfind('/')+1:])
        self.qlog = qlog
        Thread.__init__(self)
 
    def add_msg(self,msg):
        # send a message to UI
        self.qlog.put(msg)
 
    def run(self):
        self.add_msg(u"Saving %s into %s" % (self.url,self.fname))
        try:
            urllib.urlretrieve(self.url,self.fname)
        except:
            self.add_msg(u"Error downloading %s" % (self.url))
        else:
            self.add_msg(u"%s finished" % (self.url))
 
class mt_page_download(object):
    def __init__(self):
        self.lock = e32.Ao_lock()
        self.qlog = Queue()
        app.title = u"MT Demo"
        app.screen = "normal"        
        app.menu = [(u"Load URL list", self.load_list),
                    (u"Exit", self.close_app)]
        app.body = Text()
        self.lst = u"e:\\python\\urls.txt"
        self.running = True
        self.run()
 
    def load_list(self):
        lst = query(u"Path to URL list",'text',self.lst)
        if lst is not None:
            self.lst = lst
            self.create_threads()
 
    def create_threads(self):
        try:
            urls = open(self.lst,'rt').readlines()
            urls = [ url.replace('\n','') for url in urls if len(url) ]
            urls = [ url.strip() for url in urls if len(url.strip()) ]
        except:
            self.add_msg(u"Could not open %s" % self.lst)
        else:
            self.add_msg(u"Creating threads for %s" % self.lst)
            [ get_page(url,self.qlog).run() for url in urls ]
 
    def close_app(self):
        self.running = False
        self.lock.signal()
 
    def add_msg(self,msg):
        app.body.add(msg + u"\u2029")
 
    def run(self):
        while self.running:
            # create a loop and check to incoming messages
            e32.ao_yield()
            try:
                msg = self.qlog.get(True,1)
            except:
                continue
            else:
                self.add_msg(msg)
        self.lock.wait()
        app.set_exit()
 
mt = mt_page_download()
