# Multithread demo1
from threading import Thread
from time import sleep

def mythread(n,m):
    for i in xrange(n):
        print "-->",i
        sleep(m)

t = Thread(target=mythread,args=(5,2))
t.start()
t.join()
