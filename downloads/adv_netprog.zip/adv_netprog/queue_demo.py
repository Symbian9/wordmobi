# Queue demo
from threading import Thread
from Queue import Queue
from random import randint
from time import sleep

def worker_thread(ti,q):
    while True:
        job = q.get()
        if job == "exit":
            print "[%d] exit" % ti
            break
        else:
            print "[%d] New job: %s" % (ti,job)
            sleep(randint(0,3))

q = Queue()
max_jobs = 12
max_threads = 3

# creating and starting all threads
threads = [ Thread(target=worker_thread,args=(x,q)) for x in xrange(max_threads) ]
[ t.start() for t in threads ]

# dispatching jobs
[ q.put("Job%d" % x) for x in xrange(max_jobs) ]

# sending exit
[ q.put("exit") for x in xrange(max_threads) ]

# waiting all threads
[ t.join() for t in threads ]
