# File upload client
import struct
import sys
import os
import socket

if len(sys.argv) < 4:
    print "%s server_addr server_port file_to_upload" % sys.argv[0]
    sys.exit(1)
 
ip = sys.argv[1]
port = int(sys.argv[2])
full_name = sys.argv[3]
base_name = os.path.basename(full_name)
size = os.path.getsize(sys.argv[3])
 
print "Sending %s to %s:%d ..." % (base_name,ip,port)
 
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect((ip,port))
f = open(full_name,"rb")
header = "%s\n%s\n" % (base_name,struct.pack(">L",size))
s.sendall(header)
while True:
    data = f.read(1024)
    if not data:
        break
    s.sendall(data)
 
s.close()
f.close()
