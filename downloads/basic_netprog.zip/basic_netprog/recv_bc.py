# Receiving multicast message
import socket
 
PORT = 54321
sock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
sock.bind(('0.0.0.0',PORT))
 
for i in range(10):
    (data,addr) = sock.recvfrom(1500)
    print "Received ",data,"from",addr
