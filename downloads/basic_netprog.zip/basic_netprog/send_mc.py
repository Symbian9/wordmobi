# Sending multicast from mobile
import e32
import socket
from appuifw import note, popup_menu

GROUP = "224.202.20.30"
PORT = 54321

def sel_access_point():
    aps = socket.access_points()
    if not aps:
        return False
 
    ap_labels = map(lambda x: x['name'], aps)
    item = popup_menu(ap_labels,u"Access points:")
    if item is None:
        return False
 
    socket.set_default_access_point(aps[item]["name"])
 
    return True
 
if sel_access_point():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    for i in range(10):
        n = sock.sendto('hello world',(GROUP,PORT))
        print "Message sent (%d bytes)" % n
        e32.ao_sleep(2)
