# File like sockets - proto client
# btsocket can be used as well
import socket
import struct
import random
 
sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
sock.connect(('127.0.0.1',54321))
 
fsock = sock.makefile()
# creating a random header
version = random.randint(0,5)
size = random.randint(0,10)
header = struct.pack('>LL',version,size)
print "Version:",version
print "Size:",size
fsock.write(header)
data = 'X'*size
print "Data:",data
fsock.write(data)
fsock.flush()
sock.close()
