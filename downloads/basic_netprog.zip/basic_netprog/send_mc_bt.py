# Sending multicast from mobile
import e32
import btsocket
from appuifw import note, popup_menu

GROUP = "224.202.20.30"
PORT = 54321

def sel_access_point_bt():
    aps = btsocket.access_points()
    if not aps:
        return None
    ap_labels = map(lambda x: x['name'],aps)
    item = popup_menu(ap_labels, u"Access point:")
    if item is None:
        return None
    apo = btsocket.access_point(aps[item]['iapid'])
    btsocket.set_default_access_point(apo)
    return apo
 
apo = sel_access_point_bt()
if apo is not None:
    apo.start()
    sock = btsocket.socket(btsocket.AF_INET, btsocket.SOCK_DGRAM)
    for i in range(10):
        n = sock.sendto('hello world',(GROUP,PORT))
        print "Message sent (%d bytes)" % n
        e32.ao_sleep(2)
