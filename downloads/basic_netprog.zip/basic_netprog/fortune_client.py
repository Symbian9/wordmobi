# Fortune client
 
from socket import *
from appuifw import note

HOST = "10.0.0.100"
PORT = 54321
 
s = socket(AF_INET,SOCK_STREAM)
s.connect((HOST,PORT))
 
fortune = u""
while True:
    data = s.recv(1024)
    if not data:
        break
    fortune += data
 
s.close()
 
note(fortune,"info")
