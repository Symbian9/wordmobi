# btsocket can be used as well
import socket 

s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
try:
    s.connect(('nokia.com',2222))
except:
    print "Can't connect"

try:
    s.connect(('nokia.com',2222))
except socket.error, e:
    print "ERROR: %s" % e

try:
    s.connect(('nokiacom',2222))
except socket.gaierror, e:
    print "ADDR ERROR: %s" % e
except socket.error, e:
    print "ERROR: %s" % e
except:
    print "Can't connect"    
