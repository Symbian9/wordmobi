# Sending broadcast messages
import socket
import time

BCIP = "255.255.255.255"
PORT = 54321
 
sock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
sock.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST, True)
for i in range(10):
    n = sock.sendto('hello world',(BCIP,PORT))
    print "Message sent (%d bytes)" % n
    time.sleep(2)
