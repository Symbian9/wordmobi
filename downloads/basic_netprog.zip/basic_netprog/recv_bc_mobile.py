# Receiving broadcast messages
import socket
from appuifw import popup_menu

PORT = 54321
sock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
sock.bind(('0.0.0.0',PORT))

def sel_access_point():
    aps = socket.access_points()
    if not aps:
        return False
 
    ap_labels = map(lambda x: x['name'], aps)
    item = popup_menu(ap_labels,u"Access points:")
    if item is None:
        return False
 
    socket.set_default_access_point(aps[item]["name"])
 
    return True
 
if sel_access_point(): 
    for i in range(10):
        (data,addr) = sock.recvfrom(1500)
        print "Received ",data,"from",addr
