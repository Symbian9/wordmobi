# File like sockets - proto server
# btsocket can be used as well
import socket
import struct
 
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.bind(('127.0.0.1',54321))
s.listen(1)
while True:
    sock,addr = s.accept()
    fsock = sock.makefile()
    print "New connection from",addr
    # decoding header
    header = fsock.read(8)
    (version,size) = struct.unpack('>LL',header)
    print "Version:",version
    print "Size:",size
    data = fsock.read(size)
    print "Data:",data
    sock.close()
