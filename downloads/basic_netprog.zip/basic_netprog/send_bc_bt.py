# Sending broadcast messages
import btsocket
import e32

BCIP = "255.255.255.255"
PORT = 54321
 
sock = btsocket.socket(btsocket.AF_INET,btsocket.SOCK_DGRAM)
sock.setsockopt(btsocket.SOL_SOCKET,btsocket.SO_BROADCAST, True)
for i in range(10):
    n = sock.sendto('hello world',(BCIP,PORT))
    print "Message sent (%d bytes)" % n
    e32.ao_sleep(2)
