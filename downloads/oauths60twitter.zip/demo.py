# http://oauth.googlecode.com/svn/code/python/oauth/example/client.py
# http://djangosnippets.org/snippets/1353/

import sys
sys.path.append(u"e:\\Python\\")

import httplib
import oauth 
import pickle
import simplejson as json
import urllib
import e32
import appuifw
import time
import os

class TwitterOAut(object):
    SERVER = 'twitter.com'
    REQUEST_TOKEN_URL = 'https://api.twitter.com/oauth/request_token'
    ACCESS_TOKEN_URL = 'https://api.twitter.com/oauth/access_token'
    AUTHORIZATION_URL = 'https://api.twitter.com/oauth/authorize'

    def __init__(self,consumer_key,consumer_secret,auth_file):
        self.consumer_key = consumer_key
        self.consumer_secret = consumer_secret
        self.auth_file = auth_file
        self.connection = httplib.HTTPSConnection(self.SERVER)
        self.consumer = oauth.OAuthConsumer(self.consumer_key, self.consumer_secret)
        self.signature_method = oauth.OAuthSignatureMethod_HMAC_SHA1()
        self.access_token = self.load_token()
        self.validate_access_token()
        self.got_pin = False

    def save_token(self,token):
        f = open(self.auth_file,"wb")
        d = { 'key':str(token.key), 'secret':str(token.secret) }
        pickle.dump(d,f)
        f.close()

    def load_token(self):
        try:
            f = open(self.auth_file,"rb")
            d = pickle.load(f)
            access_token = oauth.OAuthToken(d['key'],d['secret'])
        except:
            access_token = None
        return access_token

    def fetch_response(self, oauth_request):
        url = oauth_request.to_url()
        self.connection.request(oauth_request.http_method,url)
        response = self.connection.getresponse()
        return response.read()

    def get_pin(self,url):

        name = "html_" + time.strftime("%Y%m%d_%H%M%S", time.localtime()) + ".html"
        name = os.path.join("e:\\", name)

        fp = open(name,"wt")
        fp.write('<html>')
        fp.write('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>')
        fp.write('<body text="#333333" bgcolor="#c0deed" link="#0084b4">')
        fp.write('You will be redirect to twitter site. Please, login and authorize wordmobi.</br>')
        fp.write('After, write down the displayed PIN code, close the browser and provide the PIN code when requested.</br></br>')
        fp.write('<h2><a href="%s">Please, clique here to go to twitter site.</a></h2>' % url)
        fp.write("</body></html>")
        fp.close()

        def get_pin_done():
            self.got_pin = True

        self.got_pin = False
        viewer = appuifw.Content_handler(get_pin_done)
        
        try:
            viewer.open(name)
        except:
            appuifw.note()

    def validate_access_token(self):        
        if self.access_token:
            return
        else:
            oauth_req = oauth.OAuthRequest.from_consumer_and_token(self.consumer,
                                                                   http_url=self.REQUEST_TOKEN_URL,
                                                                   parameters={'oauth_callback': 'oob'}) 
            oauth_req.sign_request(self.signature_method,self.consumer,None)
            resp = self.fetch_response(oauth_req)
            token = oauth.OAuthToken.from_string(resp)
            
            auth_url = "%s?oauth_token=%s" % (self.AUTHORIZATION_URL, token.key)
            self.get_pin(auth_url)

            while not self.got_pin:
                e32.ao_yield()
                e32.ao_sleep(1)

            oauth_verifier = appuifw.query(u"PIN code:","number")
            if oauth_verifier is not None:
                oauth_req = oauth.OAuthRequest.from_consumer_and_token(self.consumer,
                                                                       token=token,
                                                                       http_url=self.ACCESS_TOKEN_URL,
                                                                       parameters={'oauth_verifier': oauth_verifier})
                oauth_req.sign_request(self.signature_method,self.consumer,token)
                resp = self.fetch_response(oauth_req)
                self.access_token = oauth.OAuthToken.from_string(resp) 
                self.save_token(self.access_token)
            else:
                self.access_token = None

    def get_user_timeline(self,page=1,count=20):
        params = {"page":page,"count":count}
        URL = 'https://api.twitter.com/1/statuses/home_timeline.json'
        oauth_req = oauth.OAuthRequest.from_consumer_and_token(self.consumer,
                                                               http_method='GET',
                                                               token=self.access_token,
                                                               parameters=params,
                                                               http_url=URL)
        oauth_req.sign_request(self.signature_method, self.consumer, self.access_token)
        resp = self.fetch_response(oauth_req)
        return json.loads(resp)

                                                               
# key and secret you got from twitter when registering an application
CONSUMER_KEY = '<put your consumer key here>'
CONSUMER_SECRET = '<put your consumer secret here>'
# define where your token will be saved
AUTH_FILE = "e:\\Python\\auth_token.bin"

tw = TwitterOAut(CONSUMER_KEY,CONSUMER_SECRET,AUTH_FILE)
utl = tw.get_user_timeline()
entries = [ unicode(e['text']) for e in utl ]
appuifw.popup_menu(entries,u"Last tweets:")
