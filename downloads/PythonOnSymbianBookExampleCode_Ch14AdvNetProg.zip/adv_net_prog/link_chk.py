'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# Link Checker demo
import sys
sys.path.append('e:\\Python')
try:
    # Try to import 'btsocket' as 'socket' 
    sys.modules['socket'] = __import__('btsocket')
except ImportError:
    pass
import socket
from BeautifulSoup import BeautifulSoup
import os
import e32
import urllib
import hashlib
from appuifw import *

class LCOpener(urllib.FancyURLopener):
    """ For mediawiki it is necessary to change the http agent.
        See:
        http://wolfprojects.altervista.org/changeua.php
        http://stackoverflow.com/questions/120061/fetch-a-wikipedia-article-with-python
    """
    version = 'Mozilla/5.0'
    
class LinkChecker(object):
    def __init__(self):
        self.lock = e32.Ao_lock()
        self.dir = "e:\\linkchecker"
        if not os.path.isdir(self.dir):
            os.makedirs(self.dir)
        self.apo = None
        self.url = u'http://www.'
        self.running = False
        app.title = u"Link Checker"
        app.screen = "normal"
        app.menu = [(u"Check URL",self.check_url),
                    (u"Exit", self.close_app)]
        self.body = Text()
        app.body = self.body
        self.lock.wait()

    def close_app(self):
        self.lock.signal()

    def sel_access_point(self):
        """ Select and set the default access point.
            Return the access point object if the selection was done or None if not
        """
        aps = socket.access_points()
        if not aps:
            note(u"No access points available","error")
            return None
        
        ap_labels = map(lambda x: x['name'], aps)
        item = popup_menu(ap_labels,u"Access points:")
        if item is None:
            return None
        
        apo = socket.access_point(aps[item]['iapid'])
        socket.set_default_access_point(apo)
        
        return apo

    def check_url(self):
        if self.running:
            note(u"There is a checking already in progress",u"info")
            return
        self.running = True
        url = query(u"URL to check", "text", self.url)
        if url is not None:
            self.url = url
            self.apo = self.sel_access_point()
            if self.apo:
                self.body.clear()
                self.run_checker()
        self.running = False

    def run_checker(self):
        self.body.add(u"* Downloading page: %s ...\n" % self.url)
        fn = os.path.join(self.dir,'temp.html')
        try:
            urllib.urlretrieve(self.url,fn)
        except Exception, e:
            try:
                self.body.add(repr(e))
            except:
                self.body.add(u"Could not download " + self.url)
            return
        self.body.add(u"* Parsing links ...\n")
        page = open(fn,'rb').read()
        try:
            soup = BeautifulSoup(page)
        except:
            self.body.add(u"* BeautifulSoup error when decoding html. Aborted.")
            return
        tags = soup.findAll({'img':True,'a':True})
        links = {}
        bad_links = []
        for n,tag in enumerate(tags):
            if 'href' in tag:
                link = tag['href']
            elif 'img' in tag:
                link = tag['src']
            else:
                link=u''
            # just check external links 
            if link.startswith(u'http'):
                # not handling internal links
                link = link.split(u'#')[0]
                # using a hash to avoid repeated links
                h = hashlib.md5()
                h.update(link.encode('utf-8'))
                links[h.digest()] = link
        nl = len(links)
        for n,k in enumerate(links):
            link = links[k]
            msg = u"[%d/%d] Checking %s " % (n+1,nl,link)
            self.body.add(msg)
            (valid,info) = self.check_link(link.encode('utf-8'))
            if valid:
                msg = u"==> Passed\n"
            else:
                msg = u"==> Failed: %s\n" % info
                bad_links.append(link)
            self.body.add(msg)
        msg = u"* Summary: %d links (%d failed)\n" % (nl,len(bad_links))
        self.body.add(msg)
        for link in bad_links:
            self.body.add(u"==> %s failed\n" % link)
        self.body.add(u"* Finished")
        
    def check_link(self,link):
        """ Check if link (encoded in utf-8) exists.
            Return (True,'') or (False,'error message')
        """
        try:
            page = LCOpener().open(link)
        except Exception, e:
            return (False,unicode(repr(e)))
        else:
           return (True,u'')

lc = LinkChecker()    
