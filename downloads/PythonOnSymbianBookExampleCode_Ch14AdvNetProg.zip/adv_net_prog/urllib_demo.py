'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# urllib demo 1
import urllib
# returns a file like interface
furl = urllib.urlopen("http://wiki.forum.nokia.com/")
# reading the "file"
contents = furl.read()
# saving the page contents
flocal = open("wikiforumnokia.html","wt")
flocal.write(contents)


urllib.urlretrieve("http://wiki.forum.nokia.com/","wikiforumnokia.html")


params = urllib.urlencode({'name': 'My name is bond', 'phone':'007007'})
url = "www.exemplo.com/yourname?" + params
print url


