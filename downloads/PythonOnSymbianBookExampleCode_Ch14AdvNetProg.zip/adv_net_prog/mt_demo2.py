'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# Multithread demo2
from threading import Thread
from time import sleep

class MyThread(Thread):
    def __init__(self,n,m):
        self.n = n
        self.m = m
        Thread.__init__(self)
    def run(self):
        for i in xrange(self.n):
            print "-->",i
            sleep(self.m)

t = MyThread(5,2)
t.start()
t.join()
