'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# XML-RPC demo 1
import xmlrpclib
blog = 'http://wordmobi.wordpress.com/xmlrpc.php'
server = xmlrpclib.ServerProxy(blog)
rposts = server.metaWeblog.getRecentPosts(0,"put_user_here","put_pass_here", 5)
for post in rposts:
    print "-> %s" % post['title']

# XML-RPC demo
cats = server.wp.getCategories(0,"put_user_here","put_pass_here")
for c in cats:
    print c['categoryName']
