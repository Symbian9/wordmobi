'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
# Multithread demo1
from threading import Thread
from time import sleep

def mythread(n,m):
    for i in xrange(n):
        print "-->",i
        sleep(m)

t = Thread(target=mythread,args=(5,2))
t.start()
t.join()
