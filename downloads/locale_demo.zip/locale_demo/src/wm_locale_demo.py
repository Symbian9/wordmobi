'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''

import sys
sys.path.append(r'e:\python')
 
import appuifw
import e32
import wm_locale
 
class Locale_Demo(object):
    def __init__(self):
        appuifw.app.exit_key_handler = self.close
        appuifw.app.title = u"Locale Demo"
        appuifw.app.screen = 'normal'
        self.update_locale()
        self.app_lock = e32.Ao_lock()
 
    def close(self):
        self.app_lock.signal()
 
    def about(self):
        appuifw.note( u"Locale Demo", "info" )
 
    def update_locale(self,lang=""):
        self.labels = wm_locale.Locale(lang)
        self.refresh()
 
    def refresh(self):
        entries = [
            self.labels.loc.zero,
            self.labels.loc.one,
            self.labels.loc.two,
            self.labels.loc.three,
            self.labels.loc.four,
            self.labels.loc.five,
            self.labels.loc.six,
            self.labels.loc.seven,
            self.labels.loc.eight,
            self.labels.loc.nine
            ]
 
        self.body = appuifw.Listbox(entries)
 
        self.menu = [
            (self.labels.loc.change_language, (
                (self.labels.loc.english_us, lambda: self.update_locale("en_US")),
                (self.labels.loc.finnish, lambda: self.update_locale("fi")),
                (self.labels.loc.hungarian, lambda: self.update_locale("hu")),
                (self.labels.loc.portuguese_br, lambda: self.update_locale("pt_BR"))
                )
             ),
            (self.labels.loc.about, self.about),
            (self.labels.loc.exit, self.close)
            ]
 
        appuifw.app.menu = self.menu
        appuifw.app.body = self.body
 
    def run(self):
        self.app_lock.wait()
        appuifw.app.menu = []
        appuifw.app.body = None
        appuifw.app.set_exit()
 
if __name__ == "__main__":
 
    ld = Locale_Demo()
    ld.run()
	
