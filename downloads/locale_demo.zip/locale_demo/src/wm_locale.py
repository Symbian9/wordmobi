'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''
 
__all__ = [ "Locale" ]
 
class Loc_Data(object):
    "Translation data holder"
    pass
 
class Default(object):
    "Default language support"
    def __init__(self):
        self.loc = Loc_Data()
        self.loc.zero = u'Zero'
        self.loc.one = u'One'
        self.loc.two = u'Two'
        self.loc.three = u'Three'
        self.loc.four = u'Four'
        self.loc.five = u'Five'
        self.loc.six = u'Six'
        self.loc.seven = u'Seven'
        self.loc.eight = u'Eight'
        self.loc.nine = u'Nine'
        self.loc.change_language = u'Change Language'
        self.loc.english_us = u'English (USA)'
        self.loc.finnish = u'Finnish'
        self.loc.hungarian = u'Hungarian'
        self.loc.portuguese_br = u'Portuguese (Brazil)'
        self.loc.about = u'About'
        self.loc.exit = u'Exit'
 
class Locale(Default):
    "Multiple language support class"
 
    LOC_MODULE = "wm_locale_%s"
 
    def __init__(self,lang = ""):
        "Load all locale strings for one specific language or default if empty"        
        self.set_locale(lang)
 
    def set_locale(self,lang = ""):
        "Load all locale strings for one specific language or default if empty"
        Default.__init__(self)
 
        try:
            lang_mod = __import__( self.LOC_MODULE % ( lang ) )
        except ImportError:
            pass
        else:
            self.merge_locale(lang_mod)
 
    def merge_locale(self, lang_mod):
        "Merge new location string into default locale"
 
        # replace existing strings and keep old ones
        # if it is missing in the locale module
        for k,v in self.loc.__dict__.iteritems():
            if hasattr(lang_mod,k):
                nv = lang_mod.__getattribute__(k)
                self.loc.__setattr__(k,nv)  
 
