'''
# Symbian Foundation Example Code
#
# This software is in the public domain. No copyright is claimed, and you
# may use it for any purpose without license from the Symbian Foundation.
# No warranty for any purpose is expressed or implied by the authors or
# the Symbian Foundation.
'''

import sys
sys.path.append(r'e:\python')
sys.path.append(r'c:\data\python\localedemo')
sys.path.append(r'c:\data\python\localedemo\loc')
sys.path.append(r'e:\data\python\localedemo')
sys.path.append(r'e:\data\python\localedemo\loc')
 
import appuifw
import e32
import wm_locale

from wm_locale_demo import Locale_Demo
 
ld = Locale_Demo()
ld.run()
	
